This pack is based on the Emissive Textures pack by videogamer1002. Now ported to 1.16!

Textures in this pack may be used for personal use and included in mixed texture packs as such.

Textures in this pack may be used publicly, but credit must be given to Liamdude.

Pack created and compiled by Liamdude and Drax.